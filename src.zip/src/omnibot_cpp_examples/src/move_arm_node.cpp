// #include <rclcpp/rclcpp.hpp>
// #include <moveit/move_group_interface/move_group_interface.h>
// #include <geometry_msgs/msg/point.hpp>
// #include <tf2_ros/buffer.h>
// #include <tf2_ros/transform_listener.h>

// class MoveArmNode : public rclcpp::Node
// {
// public:
//   MoveArmNode() : Node("move_arm_node")
//   {
//     // Initialize the Transform Listener
//     tf2_ros::Buffer tf_buffer(get_clock());
//     tf2_ros::TransformListener tf_listener(tf_buffer);

//     // Create the MoveGroupInterface with required arguments
//     moveit::planning_interface::MoveGroupInterface move_group(shared_from_this(), "arm", tf_buffer);

//     // Set the end effector link name
//     move_group.setEndEffectorLink("tool0"); // Replace with your actual end effector link name

//     // Set some options (optional)
//     move_group.setPlanningTime(10.0); // Allow up to 10 seconds for planning
//     move_group.setMaxVelocityScalingFactor(0.1); // 10% of the max velocity
//     move_group.setMaxAccelerationScalingFactor(0.1); // 10% of the max acceleration

//     // Define a target position for the end effector (in meters)
//     geometry_msgs::msg::Point target_position;
//     target_position.x = 0.7; // Replace with desired position in x
//     target_position.y = 0.0; // Replace with desired position in y
//     target_position.z = 1.0; // Replace with desired position in z

//     // Move the arm to the target position
//     moveToTargetPosition(move_group, target_position);
//   }

// private:
//   // Function to move the robot arm to the target position
//   void moveToTargetPosition(moveit::planning_interface::MoveGroupInterface& move_group,
//                              const geometry_msgs::msg::Point& target_position)
//   {
//     // Create a Pose target
//     geometry_msgs::msg::Pose target_pose;
//     target_pose.position = target_position;

//     // Set the target pose for the end effector
//     move_group.setPoseTarget(target_pose);

//     // Plan and execute the motion
//     moveit::planning_interface::MoveGroupInterface::Plan plan;
//     move_group.plan(plan);
//     move_group.execute(plan);
//   }
// };

// int main(int argc, char **argv)
// {
//   rclcpp::init(argc, argv);
//   rclcpp::spin(std::make_shared<MoveArmNode>());
//   rclcpp::shutdown();
//   return 0;
// }
