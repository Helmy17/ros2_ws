import rclpy
from rclpy.node import Node
import tf2_ros
from tf_transformations import euler_from_quaternion
import serial


class JointAngleSender(Node):
    def __init__(self):
        super().__init__('joint_angle_sender')

        # Setup Serial Communication (Change port and baudrate accordingly)
        self.arduino = serial.Serial('/dev/ttyACM0', 115200, timeout=1)

        # TF Listener
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Joint names (update based on actual robot joints)
        self.joint_names = ['link0', 'link1', 'link2', 'link3', 'link4', 'link5', 'link6']

        # Specify which joints rotate around X and which around Z
        self.x_rotation_joints = [1, 2, 3]  # Indices of joints rotating around X-axis
        self.y_rotation_joints = [4]
        self.z_rotation_joints = [0, 5]  # Indices of joints rotating around Z-axis

        # Timer to fetch joint angles
        self.timer = self.create_timer(0.1, self.send_joint_angles)

    def send_joint_angles(self):
        try:
            # Initialize joint angle variables
            j1, j2, j3, j4, j5, j6 = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0

            # Get transformations and store angles in variables
            for i in range(6):  # Only need 6 joint angles
                parent = self.joint_names[i]
                child = self.joint_names[i + 1]
                transform = self.tf_buffer.lookup_transform(parent, child, rclpy.time.Time())
                q = transform.transform.rotation
                euler = euler_from_quaternion([q.x, q.y, q.z, q.w])

                # Determine which axis to extract the angle from
                if i in self.x_rotation_joints:
                    angle = round(euler[0], 3)  # Extract Roll (X-axis rotation)
                elif i in self.z_rotation_joints:
                    angle = round(euler[2], 3)  # Extract Yaw (Z-axis rotation)
                else:
                    angle = round(euler[1], 3)  # Default to Pitch (Y-axis rotation)

                # Assign to individual variables
                if i == 0:
                    j1 = angle
                elif i == 1:
                    j2 = angle
                elif i == 2:
                    j3 = angle
                elif i == 3:
                    j4 = angle
                elif i == 4:
                    j5 = angle
                elif i == 5:
                    j6 = angle

            # Send formatted string to Arduino
            # angles_str = f"{j2},{j1},{j3},{j4},{j5},{j6}\n"
            angles_str = f"{j2},{j4}\n"
            self.arduino.write(angles_str.encode())

            self.get_logger().info(f"Sent angles: {angles_str}")

        except Exception as e:
            self.get_logger().warn(f"Could not send joint angles: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = JointAngleSender()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
