import rclpy
from rclpy.node import Node
from moveit_commander import MoveGroupCommander, PlanningSceneInterface, RobotCommander
import serial
import time

class JointAngleSender(Node):
    def __init__(self):
        super().__init__('joint_angle_sender')

        # Initialize MoveIt
        self.robot = RobotCommander()
        self.group = MoveGroupCommander("arm")

        # Connect to Arduino via serial
        try:
            self.arduino = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
            time.sleep(2)  # Give Arduino time to reset
            self.get_logger().info("Serial connection to Arduino established.")
        except serial.SerialException:
            self.get_logger().error("Failed to connect to Arduino.")
            return

        # Timer to send joint values periodically
        self.create_timer(0.5, self.send_joint_angles)

    def send_joint_angles(self):
        joint_values = self.group.get_current_joint_values()

        # Format the joint values as comma-separated string
        data_str = ','.join([f"{angle:.2f}" for angle in joint_values]) + '\n'
        self.get_logger().info(f"Sending joint angles: {data_str.strip()}")

        # Send to Arduino
        self.arduino.write(data_str.encode())

def main(args=None):
    rclpy.init(args=args)
    node = JointAngleSender()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
