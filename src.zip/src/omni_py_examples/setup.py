from setuptools import find_packages, setup

package_name = 'omni_py_examples'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pc',
    maintainer_email='pc@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'simple_parameter = omni_py_examples.simple_parameter:main',
            'simple_service_server = omni_py_examples.simple_service_server:main',
            'simple_service_client = omni_py_examples.simple_service_client:main',
            'simple_action_server = omni_py_examples.simple_action_server:main',
            'simple_action_client = omni_py_examples.simple_action_client:main',
            'suction_control = omni_py_examples.suction_control:main',
            'reading_tf = omni_py_examples.reading_tf:main',
            'joint_angle_reader = omni_py_examples.joint_angle_reader:main',
        ],
    },
)
