from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import TimerAction
import os
from launch_ros.parameter_descriptions import ParameterValue
from launch.substitutions import Command
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():

    # Load the robot description from xacro
    robot_description = ParameterValue(
        Command([
            "xacro ",
            os.path.join(get_package_share_directory("omni_description"), "urdf", "omni_description.urdf.xacro")
        ]),
        value_type=str
    )

    # Paths
    controllers_yaml = os.path.join(
        get_package_share_directory("omnibot_controller"),
        "config",
        "omnibot_controllers.yaml"
    )

    # Robot State Publisher
    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{"robot_description": robot_description}]
    )

    # ros2_control_node (Controller Manager)
    control_node = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[
            {"robot_description": robot_description},
            controllers_yaml
        ],
        output="screen"
    )

    # Spawners (delayed to wait for controller manager)
    delay_spawners = TimerAction(
        period=3.0,
        actions=[
            Node(
                package="controller_manager",
                executable="spawner",
                arguments=["joint_state_broadcaster", "--controller-manager", "/controller_manager"],
                output="screen"
            ),
            Node(
                package="controller_manager",
                executable="spawner",
                arguments=["arm_controller", "--controller-manager", "/controller_manager"],
                output="screen"
            ),
        ]
    )

    return LaunchDescription([
        robot_state_publisher,
        control_node,
        delay_spawners
    ])
