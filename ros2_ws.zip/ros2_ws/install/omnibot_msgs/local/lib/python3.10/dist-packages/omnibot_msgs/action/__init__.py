from omnibot_msgs.action._fibonacci import Fibonacci  # noqa: F401
