// generated from rosidl_generator_c/resource/idl.h.em
// with input from omnibot_msgs:srv/EulerToQuaternion.idl
// generated code does not contain a copyright notice

#ifndef OMNIBOT_MSGS__SRV__EULER_TO_QUATERNION_H_
#define OMNIBOT_MSGS__SRV__EULER_TO_QUATERNION_H_

#include "omnibot_msgs/srv/detail/euler_to_quaternion__struct.h"
#include "omnibot_msgs/srv/detail/euler_to_quaternion__functions.h"
#include "omnibot_msgs/srv/detail/euler_to_quaternion__type_support.h"

#endif  // OMNIBOT_MSGS__SRV__EULER_TO_QUATERNION_H_
