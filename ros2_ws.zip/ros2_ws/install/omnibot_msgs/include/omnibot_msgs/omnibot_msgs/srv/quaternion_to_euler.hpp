// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OMNIBOT_MSGS__SRV__QUATERNION_TO_EULER_HPP_
#define OMNIBOT_MSGS__SRV__QUATERNION_TO_EULER_HPP_

#include "omnibot_msgs/srv/detail/quaternion_to_euler__struct.hpp"
#include "omnibot_msgs/srv/detail/quaternion_to_euler__builder.hpp"
#include "omnibot_msgs/srv/detail/quaternion_to_euler__traits.hpp"
#include "omnibot_msgs/srv/detail/quaternion_to_euler__type_support.hpp"

#endif  // OMNIBOT_MSGS__SRV__QUATERNION_TO_EULER_HPP_
