// generated from rosidl_generator_c/resource/idl.h.em
// with input from omnibot_msgs:srv/AddTwoInts.idl
// generated code does not contain a copyright notice

#ifndef OMNIBOT_MSGS__SRV__ADD_TWO_INTS_H_
#define OMNIBOT_MSGS__SRV__ADD_TWO_INTS_H_

#include "omnibot_msgs/srv/detail/add_two_ints__struct.h"
#include "omnibot_msgs/srv/detail/add_two_ints__functions.h"
#include "omnibot_msgs/srv/detail/add_two_ints__type_support.h"

#endif  // OMNIBOT_MSGS__SRV__ADD_TWO_INTS_H_
