// generated from rosidl_generator_c/resource/idl.h.em
// with input from omnibot_msgs:srv/QuaternionToEuler.idl
// generated code does not contain a copyright notice

#ifndef OMNIBOT_MSGS__SRV__QUATERNION_TO_EULER_H_
#define OMNIBOT_MSGS__SRV__QUATERNION_TO_EULER_H_

#include "omnibot_msgs/srv/detail/quaternion_to_euler__struct.h"
#include "omnibot_msgs/srv/detail/quaternion_to_euler__functions.h"
#include "omnibot_msgs/srv/detail/quaternion_to_euler__type_support.h"

#endif  // OMNIBOT_MSGS__SRV__QUATERNION_TO_EULER_H_
