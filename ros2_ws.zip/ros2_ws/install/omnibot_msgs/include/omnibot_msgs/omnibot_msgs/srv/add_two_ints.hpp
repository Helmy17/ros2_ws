// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OMNIBOT_MSGS__SRV__ADD_TWO_INTS_HPP_
#define OMNIBOT_MSGS__SRV__ADD_TWO_INTS_HPP_

#include "omnibot_msgs/srv/detail/add_two_ints__struct.hpp"
#include "omnibot_msgs/srv/detail/add_two_ints__builder.hpp"
#include "omnibot_msgs/srv/detail/add_two_ints__traits.hpp"
#include "omnibot_msgs/srv/detail/add_two_ints__type_support.hpp"

#endif  // OMNIBOT_MSGS__SRV__ADD_TWO_INTS_HPP_
