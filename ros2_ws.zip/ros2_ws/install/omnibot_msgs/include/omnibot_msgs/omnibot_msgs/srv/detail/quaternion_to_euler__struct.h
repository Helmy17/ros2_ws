// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from omnibot_msgs:srv/QuaternionToEuler.idl
// generated code does not contain a copyright notice

#ifndef OMNIBOT_MSGS__SRV__DETAIL__QUATERNION_TO_EULER__STRUCT_H_
#define OMNIBOT_MSGS__SRV__DETAIL__QUATERNION_TO_EULER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/QuaternionToEuler in the package omnibot_msgs.
typedef struct omnibot_msgs__srv__QuaternionToEuler_Request
{
  double x;
  double y;
  double z;
  double w;
} omnibot_msgs__srv__QuaternionToEuler_Request;

// Struct for a sequence of omnibot_msgs__srv__QuaternionToEuler_Request.
typedef struct omnibot_msgs__srv__QuaternionToEuler_Request__Sequence
{
  omnibot_msgs__srv__QuaternionToEuler_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} omnibot_msgs__srv__QuaternionToEuler_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/QuaternionToEuler in the package omnibot_msgs.
typedef struct omnibot_msgs__srv__QuaternionToEuler_Response
{
  double roll;
  double pitch;
  double yaw;
} omnibot_msgs__srv__QuaternionToEuler_Response;

// Struct for a sequence of omnibot_msgs__srv__QuaternionToEuler_Response.
typedef struct omnibot_msgs__srv__QuaternionToEuler_Response__Sequence
{
  omnibot_msgs__srv__QuaternionToEuler_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} omnibot_msgs__srv__QuaternionToEuler_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // OMNIBOT_MSGS__SRV__DETAIL__QUATERNION_TO_EULER__STRUCT_H_
