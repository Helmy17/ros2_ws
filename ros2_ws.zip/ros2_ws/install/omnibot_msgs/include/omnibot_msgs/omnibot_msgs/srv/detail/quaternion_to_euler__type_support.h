// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from omnibot_msgs:srv/QuaternionToEuler.idl
// generated code does not contain a copyright notice

#ifndef OMNIBOT_MSGS__SRV__DETAIL__QUATERNION_TO_EULER__TYPE_SUPPORT_H_
#define OMNIBOT_MSGS__SRV__DETAIL__QUATERNION_TO_EULER__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "omnibot_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_omnibot_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  omnibot_msgs,
  srv,
  QuaternionToEuler_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_omnibot_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  omnibot_msgs,
  srv,
  QuaternionToEuler_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_omnibot_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  omnibot_msgs,
  srv,
  QuaternionToEuler
)();

#ifdef __cplusplus
}
#endif

#endif  // OMNIBOT_MSGS__SRV__DETAIL__QUATERNION_TO_EULER__TYPE_SUPPORT_H_
