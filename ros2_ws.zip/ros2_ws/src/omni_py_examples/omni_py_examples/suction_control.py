import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from std_msgs.msg import Float64
import time


class SuctionCupController(Node):
    def __init__(self):
        super().__init__('suction_cup_controller')
        self.publisher = self.create_publisher(Float64, '/gripper_controller/commands', 10)
        self.get_logger().info("Suction Cup Controller Initialized")

    def activate_suction(self):
        msg = Float64()
        msg.data = 1.0  # Suction on
        self.publisher.publish(msg)
        self.get_logger().info("Suction activated")

    def release_suction(self):
        msg = Float64()
        msg.data = 0.0  # Suction off
        self.publisher.publish(msg)
        self.get_logger().info("Suction released")


def main(args=None):
    rclpy.init(args=args)
    node = SuctionCupController()

    # Example usage
    node.activate_suction()  # Turn on suction
    time.sleep(10)  # Wait for 10 seconds
    node.release_suction()  # Turn off suction

    rclpy.shutdown()


if __name__ == '__main__':
    main()
