#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/float64.hpp>
#include <moveit/move_group_interface/move_group_interface.h>

class OmnibotPickPlace : public rclcpp::Node {
public:
    OmnibotPickPlace() : Node("omnibot_pick_place") {
        // Publisher to control the suction cup
        suction_pub_ = this->create_publisher<std_msgs::msg::Float64>("/gripper_controller/commands", 10);
        
        // MoveIt! MoveGroupInterface for controlling the arm
        move_group_ = std::make_shared<moveit::planning_interface::MoveGroupInterface>(shared_from_this(), "arm");
        
        // Execute pick-and-place sequence
        executePickPlace();
    }

private:
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr suction_pub_;
    std::shared_ptr<moveit::planning_interface::MoveGroupInterface> move_group_;

    void moveToTarget(std::vector<double> joint_positions) {
        move_group_->setJointValueTarget(joint_positions);
        moveit::planning_interface::MoveGroupInterface::Plan plan;
        
        bool success = (move_group_->plan(plan) == moveit::core::MoveItErrorCode::SUCCESS);
        if (success) {
            RCLCPP_INFO(this->get_logger(), "Executing trajectory...");
            move_group_->execute(plan);
        } else {
            RCLCPP_ERROR(this->get_logger(), "Failed to plan motion.");
        }
    }

    void controlSuctionCup(bool activate) {
        std_msgs::msg::Float64 msg;
        msg.data = activate ? 1.0 : 0.0;
        suction_pub_->publish(msg);
        RCLCPP_INFO(this->get_logger(), "Suction cup %s", activate ? "activated" : "deactivated");
    }

    void executePickPlace() {
        // Move to pick position
        RCLCPP_INFO(this->get_logger(), "Moving to pick position...");
        moveToTarget({0.0, -1.0, 0.5, 0.0, 1.57, 0.0}); // Example values

        // Activate suction cup
        rclcpp::sleep_for(std::chrono::seconds(1)); // Delay before activating suction
        controlSuctionCup(true);

        // Move to place position
        RCLCPP_INFO(this->get_logger(), "Moving to place position...");
        moveToTarget({0.5, -0.5, 0.3, 0.0, 1.57, 0.0}); // Example values

        // Deactivate suction cup
        rclcpp::sleep_for(std::chrono::seconds(1)); // Delay before deactivating suction
        controlSuctionCup(false);
    }
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);

    auto node = std::make_shared<rclcpp::Node>("omnibot_pick_place");

    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
